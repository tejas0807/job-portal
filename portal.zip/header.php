<header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logos/logo.png" alt="image" ></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a class="active" href="index.php">Home</a></li>
                        <li><a class="active" href="features.php">News </a></li>
                        <li><a class="active" href="domain.php">Employer</a></li>
                        <li><a class="active" href="hosting.php">job seeker</a></li>
                        <li><a class="active" href="pricing.php"></a></li>
                        
                        <li><a class="active" href="contact2.php">Contact</a></li>
                    </ul>
                    
                </div>
            </div>
        </nav>
    </header>
	