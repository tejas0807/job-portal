

<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<div id="col" class="noprint">
            

                <hr class="noscreen" />

                <!-- Category -->
                <h3 ><center>Login</center></h3>
<div class="login">
                <form name="form1" method="post" action="login.php">
                  <table width="100%" border="0">
                    <tr>
                      <td><center><strong>User Name</strong></center></td>
                    </tr>
                    <tr>
        <td><span id="sprytextfield1"><center>
                        <label>
                        <input type="text" name="txtUser" id="txtUser">
                        </label>
                      <span class="textfieldRequiredMsg">*</span></span></center>
          <label></label></td>
                    </tr>
                    <tr>
                      <td><center><strong>Password</strong></center></td>
                    </tr>
                    <tr>
                <td><span id="sprytextfield2"><center>
                        <label>
                        <input type="password" name="txtPass" id="txtPass">
                        </label>
                      <span class="textfieldRequiredMsg">*</span></span></center></td>
                    </tr>
                    <tr>
                      <td><center><strong>User Type</strong></center></td>
                    </tr>
                    <tr>
                      <td style="text-align: center;"><label>
                        <select name="cmbUser" id="cmbUser">
                          <option value="JobSeeker">JobSeeker</option>
                          <option value="Employer" selected="selected">Employer</option>
                          <option value="Administrator">Administrator</option>
                          </select>
                      </label></td>
                    </tr>
                    <tr>
                      <td><label>
                        <div>
                          <input type="submit" name="button" id="button" value="Login" style=" margin-left: 648px">
                            </div>
                      </label></td>
                    </tr>
                    <tr>
                      <td><div align="center"><a href="Forget.php"><strong>Forgot Password? </strong></a></div></td>
                      
                    </tr>
                  </table>
      </form>
              </div>
                
        <script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
